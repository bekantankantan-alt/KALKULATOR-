package com.hasim.kalkulatorsuperior;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity {
 private TextView input,result;
 private String expr="";
 private boolean done=false;
 private final int bg=Color.rgb(4,8,18), panel=Color.rgb(14,25,43), blue=Color.rgb(0,174,255), cyan=Color.rgb(100,225,255), white=Color.rgb(240,249,255);
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);build();}
 private void build(){
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(10),dp(8),dp(10),dp(8));root.setBackgroundColor(bg);
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(8),0,dp(8),0);
  TextView menu=txt("☰",27,cyan);menu.setPadding(0,0,dp(14),0);head.addView(menu);
  TextView title=txt("Quickey Calculator",18,white);title.setTypeface(null,Typeface.BOLD);head.addView(title,new LinearLayout.LayoutParams(0,-1,1));
  head.addView(txt("◷",28,cyan));root.addView(head,new LinearLayout.LayoutParams(-1,dp(54)));
  LinearLayout screen=new LinearLayout(this);screen.setOrientation(1);screen.setBackground(shape(panel,8,cyan,dp(1)));
  input=txt("",31,white);input.setGravity(Gravity.TOP|Gravity.LEFT);input.setPadding(dp(10),dp(12),dp(10),dp(8));screen.addView(input,new LinearLayout.LayoutParams(-1,0,3.1f));
  TextView line=new TextView(this);line.setBackgroundColor(Color.rgb(70,151,204));screen.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
  result=txt("0",32,cyan);result.setTypeface(null,Typeface.BOLD);result.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);result.setPadding(dp(10),dp(4),dp(10),dp(4));screen.addView(result,new LinearLayout.LayoutParams(-1,0,.9f));
  LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,0,2.05f);sp.setMargins(0,dp(7),0,dp(8));root.addView(screen,sp);
  String[][] keys={{"C","%","+/−","⌫"},{"7","8","9","÷"},{"4","5","6","×"},{"1","2","3","−"},{"0",".","=","+"}};
  for(int r=0;r<5;r++){LinearLayout row=new LinearLayout(this);for(int c=0;c<4;c++){String k=keys[r][c];String kind=r==0?"utility":(k.equals("=")?"equals":(c==3?"operator":"number"));Button button=make(k,kind);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.setMargins(dp(4),dp(4),dp(4),dp(4));row.addView(button,p);}root.addView(row,new LinearLayout.LayoutParams(-1,0,1));}
  setContentView(root);
 }
 private TextView txt(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
 private Button make(String s,String kind){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(s.length()>2?20:25);b.setTypeface(null,Typeface.BOLD);
  int fill=kind.equals("equals")?blue:kind.equals("operator")?Color.rgb(10,47,79):kind.equals("utility")?Color.rgb(15,38,65):panel;
  b.setTextColor(kind.equals("equals")?Color.WHITE:kind.equals("number")?white:cyan);b.setBackground(shape(fill,9,kind.equals("equals")?cyan:Color.rgb(43,123,180),dp(2)));b.setStateListAnimator(null);b.setPadding(0,0,0,0);
  b.setOnTouchListener((v,e)->{if(e.getAction()==0)v.animate().scaleX(.95f).scaleY(.95f).alpha(.75f).setDuration(65).start();else if(e.getAction()==1||e.getAction()==3)v.animate().scaleX(1).scaleY(1).alpha(1).setDuration(100).start();return false;});
  b.setOnClickListener(v->press(s));return b;
 }
 private void press(String k){
  if(k.equals("C")){expr="";done=false;update();return;}
  if(k.equals("⌫")){if(!expr.isEmpty())expr=expr.substring(0,expr.length()-1);done=false;update();return;}
  if(k.equals("=")){try{double v=new Parser(expr).parse();result.setText(fmt(v));expr=fmt(v).replace(",","");done=true;input.setText(pretty(expr));}catch(Exception e){result.setText("Error");}return;}
  if(k.equals("+/−")){if(!expr.isEmpty())try{expr=fmt(-new Parser(expr).parse()).replace(",","");done=true;}catch(Exception ignored){}update();return;}
  String token=k.equals("÷")?"/":k.equals("×")?"*":k.equals("−")?"-":k;
  if(done&&!op(k)&&!k.equals("%")&&!k.equals("."))expr="";
  done=false;expr+=token;update();
 }
 private void update(){input.setText(pretty(expr));if(expr.isEmpty()){result.setText("0");return;}try{result.setText(fmt(new Parser(expr).parse()));}catch(Exception ignored){result.setText("");}}
 private boolean op(String s){return s.equals("+")||s.equals("−")||s.equals("×")||s.equals("÷");}
 private String pretty(String s){StringBuilder o=new StringBuilder(),n=new StringBuilder();for(int i=0;i<s.length();i++){char c=s.charAt(i);if((c>='0'&&c<='9')||c=='.')n.append(c);else{if(n.length()>0){o.append(group(n.toString()));n.setLength(0);}o.append(c=='*'?'×':c=='/'?'÷':c=='-'?'−':c);}}if(n.length()>0)o.append(group(n.toString()));return o.toString();}
 private String group(String s){String[] a=s.split("\\\\.",-1);String n=a[0];StringBuilder b=new StringBuilder();for(int i=0;i<n.length();i++){if(i>0&&(n.length()-i)%3==0)b.append(',');b.append(n.charAt(i));}if(a.length>1)b.append('.').append(a[1]);return b.toString();}
 private String fmt(double d){if(!Double.isFinite(d))throw new ArithmeticException();if(Math.abs(d)<1e12&&d==Math.rint(d))return String.format(Locale.US,"%,d",(long)d);return String.format(Locale.US,"%,.8f",d).replaceAll("0+$","").replaceAll("\\\\.$","");}
 private GradientDrawable shape(int c,int r,int stroke,int w){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));d.setStroke(w,stroke);return d;}
 private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
 private static class Parser{final String s;int p=-1,ch;Parser(String s){this.s=s;}void next(){ch=++p<s.length()?s.charAt(p):-1;}boolean eat(int c){while(ch==' ')next();if(ch==c){next();return true;}return false;}double parse(){next();double x=expr();if(p<s.length())throw new RuntimeException();return x;}double expr(){double x=term();for(;;){if(eat('+'))x+=term();else if(eat('-'))x-=term();else return x;}}double term(){double x=factor();for(;;){if(eat('*'))x*=factor();else if(eat('/'))x/=factor();else return x;}}double factor(){if(eat('+'))return factor();if(eat('-'))return -factor();double x;int st=p;if(eat('(')){x=expr();if(!eat(')'))throw new RuntimeException();}else{while((ch>='0'&&ch<='9')||ch=='.')next();if(st==p)throw new RuntimeException();x=Double.parseDouble(s.substring(st,p));if(eat('%'))x/=100;}return x;}}
}

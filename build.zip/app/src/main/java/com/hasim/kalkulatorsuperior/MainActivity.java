package com.hasim.kalkulatorsuperior;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private TextView display, smallDisplay;
    private String expression = "";
    private boolean justEvaluated = false;
    private final int bg = Color.rgb(12, 18, 25);
    private final int panel = Color.rgb(23, 32, 42);
    private final int accent = Color.rgb(91, 210, 145);
    private final String[] keys = {"AC","⌫","%","÷","7","8","9","×","4","5","6","−","1","2","3","+","±","0",".","="};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUI();
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(18));
        root.setBackgroundColor(bg);

        TextView title = new TextView(this);
        title.setText("KALKULATOR");
        title.setTextColor(accent);
        title.setTextSize(13);
        title.setLetterSpacing(0.16f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("SUPERIOR  •  RINGAN & CEPAT");
        subtitle.setTextColor(Color.rgb(135,151,164));
        subtitle.setTextSize(10);
        subtitle.setPadding(0, dp(5), 0, dp(14));
        root.addView(subtitle);

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setGravity(Gravity.BOTTOM | Gravity.RIGHT);
        screen.setPadding(dp(18), dp(16), dp(18), dp(16));
        screen.setBackground(round(panel, 22));
        smallDisplay = new TextView(this);
        smallDisplay.setText("");
        smallDisplay.setTextColor(Color.rgb(145,164,177));
        smallDisplay.setTextSize(16);
        smallDisplay.setGravity(Gravity.RIGHT);
        display = new TextView(this);
        display.setText("0");
        display.setTextColor(Color.WHITE);
        display.setTextSize(42);
        display.setSingleLine(true);
        display.setGravity(Gravity.RIGHT);
        display.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        screen.addView(smallDisplay);
        screen.addView(display);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1.05f);
        sp.bottomMargin = dp(18);
        root.addView(screen, sp);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(5);
        for (String key : keys) {
            Button b = new Button(this);
            b.setText(key);
            b.setAllCaps(false);
            b.setTextSize(key.length() > 1 ? 16 : 21);
            b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            int color = key.equals("=") ? accent : (isOperator(key) || key.equals("AC") || key.equals("⌫") || key.equals("%") ? Color.rgb(38,55,64) : panel);
            b.setTextColor(key.equals("=") ? Color.rgb(8,24,18) : (isOperator(key) || key.equals("AC") || key.equals("⌫") || key.equals("%") ? accent : Color.WHITE));
            b.setBackground(round(color, 18));
            b.setStateListAnimator(null);
            b.setPadding(0, 0, 0, 0);
            GridLayout.LayoutParams p = new GridLayout.LayoutParams();
            p.width = 0; p.height = 0;
            p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            p.rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            p.setMargins(dp(4), dp(4), dp(4), dp(4));
            grid.addView(b, p);
            b.setOnTouchListener((v, e) -> {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { v.animate().scaleX(0.93f).scaleY(0.93f).alpha(0.78f).setDuration(75).start(); }
                else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(110).start(); }
                return false;
            });
            b.setOnClickListener(v -> press(key));
        }
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 2.2f));
        setContentView(root);
    }

    private void press(String key) {
        if (key.equals("AC")) { expression = ""; smallDisplay.setText(""); justEvaluated = false; update(); return; }
        if (key.equals("⌫")) { if (!expression.isEmpty()) expression = expression.substring(0, expression.length()-1); update(); return; }
        if (key.equals("=")) {
            try {
                double result = new Parser(expression).parse();
                smallDisplay.setText(expression + " =");
                expression = format(result);
                justEvaluated = true;
                update();
            } catch (Exception e) { display.setText("Error"); }
            return;
        }
        if (key.equals("±")) {
            if (!expression.isEmpty()) {
                try { expression = format(-new Parser(expression).parse()); justEvaluated = true; } catch(Exception ignored) {}
            }
            update(); return;
        }
        String token = key.equals("×") ? "*" : key.equals("÷") ? "/" : key.equals("−") ? "-" : key;
        if (justEvaluated && !isOperator(key) && !key.equals("%") && !key.equals(".")) { expression = ""; smallDisplay.setText(""); }
        justEvaluated = false;
        if (key.equals("%")) expression += "/100";
        else expression += token;
        update();
    }

    private void update() { display.setText(expression.isEmpty() ? "0" : expression.replace("*","×").replace("/","÷").replace("-","−")); }
    private boolean isOperator(String s) { return s.equals("+") || s.equals("−") || s.equals("×") || s.equals("÷"); }
    private String format(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) throw new ArithmeticException();
        if (Math.abs(d) < 1e12 && d == Math.rint(d)) return String.valueOf((long)d);
        return String.format(java.util.Locale.US, "%.8f", d).replaceAll("0+$","").replaceAll("\\.$","");
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private static class Parser {
        private final String s; private int pos = -1, ch;
        Parser(String s) { this.s = s; }
        void next() { ch = (++pos < s.length()) ? s.charAt(pos) : -1; }
        boolean eat(int c) { while (ch == ' ') next(); if (ch == c) { next(); return true; } return false; }
        double parse() { next(); double x = expr(); if (pos < s.length()) throw new RuntimeException(); return x; }
        double expr() { double x = term(); for (;;) { if (eat('+')) x += term(); else if (eat('-')) x -= term(); else return x; } }
        double term() { double x = factor(); for (;;) { if (eat('*')) x *= factor(); else if (eat('/')) x /= factor(); else return x; } }
        double factor() {
            if (eat('+')) return factor();
            if (eat('-')) return -factor();
            double x; int start = pos;
            if (eat('(')) { x = expr(); if (!eat(')')) throw new RuntimeException(); }
            else {
                while ((ch >= '0' && ch <= '9') || ch == '.') next();
                if (start == pos) throw new RuntimeException();
                x = Double.parseDouble(s.substring(start, pos));
            }
            return x;
        }
    }
}

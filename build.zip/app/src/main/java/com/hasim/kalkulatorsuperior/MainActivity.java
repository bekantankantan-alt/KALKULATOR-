package com.hasim.kalkulatorsuperior;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView display, expressionView;
    private String expression = "";
    private boolean justEvaluated = false;
    private final int bg = Color.rgb(5, 10, 23);
    private final int panel = Color.rgb(13, 24, 45);
    private final int blue = Color.rgb(35, 174, 255);
    private final int cyan = Color.rgb(105, 225, 255);
    private final int white = Color.rgb(239, 248, 255);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUI();
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(17), dp(24), dp(17), dp(15));
        root.setBackgroundColor(bg);

        TextView title = new TextView(this);
        title.setText("KALKULATOR SUPERIOR");
        title.setTextColor(cyan);
        title.setTextSize(15);
        title.setLetterSpacing(.10f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("NEON BLUE  •  SIMPLE  •  FAST");
        sub.setTextColor(Color.rgb(111, 153, 190));
        sub.setTextSize(10);
        sub.setPadding(0, dp(5), 0, dp(14));
        root.addView(sub);

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setGravity(Gravity.BOTTOM | Gravity.RIGHT);
        screen.setPadding(dp(17), dp(18), dp(17), dp(18));
        screen.setBackground(round(panel, 22, Color.rgb(23, 95, 150), dp(1)));
        expressionView = new TextView(this);
        expressionView.setText("");
        expressionView.setTextColor(Color.rgb(116, 169, 211));
        expressionView.setTextSize(17);
        expressionView.setGravity(Gravity.RIGHT);
        display = new TextView(this);
        display.setText("0");
        display.setTextColor(white);
        display.setTextSize(39);
        display.setSingleLine(true);
        display.setGravity(Gravity.RIGHT);
        display.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        screen.addView(expressionView);
        screen.addView(display);
        LinearLayout.LayoutParams screenP = new LinearLayout.LayoutParams(-1, 0, 1f);
        screenP.bottomMargin = dp(15);
        root.addView(screen, screenP);

        // Dedicated utility row: clear and delete are kept away from number keys.
        LinearLayout utility = row();
        utility.addView(key("AC", "utility", 1), weight());
        utility.addView(key("⌫", "utility", 1), weight());
        utility.addView(key("%", "utility", 1), weight());
        utility.addView(key("÷", "operator", 1), weight());
        root.addView(utility, rowParams());

        String[][] layout = {
            {"7","8","9","×"},
            {"4","5","6","−"},
            {"1","2","3","+"},
            {"±","0",".","="}
        };
        for (String[] line : layout) {
            LinearLayout r = row();
            for (String k : line) r.addView(key(k, k.equals("=") ? "equals" : (isOperator(k) ? "operator" : "number"), 1), weight());
            root.addView(r, rowParams());
        }
        setContentView(root);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }
    private LinearLayout.LayoutParams rowParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 0, 1f);
        p.setMargins(0, dp(3), 0, dp(3));
        return p;
    }
    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        p.setMargins(dp(4), dp(3), dp(4), dp(3));
        return p;
    }
    private Button key(String label, String kind, int unused) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(label.length() > 1 ? 16 : 21);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        int fill = kind.equals("equals") ? blue : kind.equals("operator") ? Color.rgb(12, 52, 86) :
                   kind.equals("utility") ? Color.rgb(17, 39, 66) : panel;
        int ink = kind.equals("equals") ? Color.rgb(2, 15, 29) : kind.equals("number") ? white : cyan;
        b.setTextColor(ink);
        b.setBackground(round(fill, 17, kind.equals("equals") ? cyan : Color.rgb(23, 75, 119), dp(1)));
        b.setStateListAnimator(null);
        b.setPadding(0,0,0,0);
        b.setOnTouchListener((v,e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) v.animate().scaleX(.93f).scaleY(.93f).alpha(.76f).setDuration(65).start();
            else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL)
                v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(105).start();
            return false;
        });
        b.setOnClickListener(v -> press(label));
        return b;
    }

    private void press(String key) {
        if (key.equals("AC")) { expression = ""; expressionView.setText(""); justEvaluated = false; update(); return; }
        if (key.equals("⌫")) {
            if (!expression.isEmpty()) expression = expression.substring(0, expression.length()-1);
            justEvaluated = false; update(); return;
        }
        if (key.equals("=")) {
            try {
                double result = new Parser(expression).parse();
                expressionView.setText(prettyExpression(expression) + " =");
                expression = formatResult(result);
                justEvaluated = true; update();
            } catch (Exception e) { display.setText("Error"); }
            return;
        }
        if (key.equals("±")) {
            if (!expression.isEmpty()) {
                try { expression = formatResult(-new Parser(expression).parse()); justEvaluated = true; } catch(Exception ignored) {}
            }
            update(); return;
        }
        String token = key.equals("×") ? "*" : key.equals("÷") ? "/" : key.equals("−") ? "-" : key;
        if (justEvaluated && !isOperator(key) && !key.equals("%") && !key.equals(".")) {
            expression = ""; expressionView.setText("");
        }
        justEvaluated = false;
        if (key.equals("%")) expression += "/100"; else expression += token;
        update();
    }

    private void update() {
        if (expression.isEmpty()) { display.setText("0"); return; }
        display.setText(prettyExpression(expression));
    }
    private String prettyExpression(String raw) {
        StringBuilder out = new StringBuilder();
        StringBuilder number = new StringBuilder();
        for (int i=0;i<raw.length();i++) {
            char c=raw.charAt(i);
            if ((c>='0' && c<='9') || c=='.') number.append(c);
            else {
                if (number.length()>0) { out.append(groupNumber(number.toString())); number.setLength(0); }
                out.append(c=='*'?'×':c=='/'?'÷':c=='-'?'−':c);
            }
        }
        if (number.length()>0) out.append(groupNumber(number.toString()));
        return out.toString();
    }
    private String groupNumber(String s) {
        String[] parts=s.split("\\\\.",-1);
        String n=parts[0];
        StringBuilder g=new StringBuilder();
        for(int i=0;i<n.length();i++) {
            if(i>0 && (n.length()-i)%3==0 && n.charAt(i)!='-') g.append('.');
            g.append(n.charAt(i));
        }
        if(parts.length>1) g.append(',').append(parts[1]);
        return g.toString();
    }
    private String formatResult(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) throw new ArithmeticException();
        if (Math.abs(d)<1e12 && d==Math.rint(d)) return String.valueOf((long)d);
        return String.format(Locale.US,"%.8f",d).replaceAll("0+$","").replaceAll("\\\\.$","");
    }
    private boolean isOperator(String s) { return s.equals("+") || s.equals("−") || s.equals("×") || s.equals("÷"); }
    private GradientDrawable round(int color, int radius, int stroke, int width) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(width,stroke); return d;
    }
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+.5f); }

    private static class Parser {
        private final String s; private int pos=-1,ch;
        Parser(String s) { this.s=s; }
        void next() { ch=(++pos<s.length())?s.charAt(pos):-1; }
        boolean eat(int c) { while(ch==' ') next(); if(ch==c){next();return true;} return false; }
        double parse() { next(); double x=expr(); if(pos<s.length()) throw new RuntimeException(); return x; }
        double expr(){double x=term();for(;;){if(eat('+'))x+=term();else if(eat('-'))x-=term();else return x;}}
        double term(){double x=factor();for(;;){if(eat('*'))x*=factor();else if(eat('/'))x/=factor();else return x;}}
        double factor(){
            if(eat('+'))return factor(); if(eat('-'))return -factor();
            double x; int start=pos;
            if(eat('(')){x=expr();if(!eat(')'))throw new RuntimeException();}
            else {while((ch>='0'&&ch<='9')||ch=='.')next();if(start==pos)throw new RuntimeException();x=Double.parseDouble(s.substring(start,pos));}
            return x;
        }
    }
}

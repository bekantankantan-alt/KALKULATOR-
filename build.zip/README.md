# Kalkulator Superior

Aplikasi kalkulator Android ringan untuk Realme Narzo 50i (Android 11).

## Build APK dengan satu upload ZIP
1. Ekstrak ZIP ini.
2. Upload seluruh isi folder ke repository GitHub (pastikan folder `.github/workflows/build.yml` ikut ter-upload).
3. Buka tab **Actions** → workflow **Build APK** → **Run workflow** (atau push ke branch `main`).
4. Setelah selesai, buka hasil run → **Artifacts** → unduh `Kalkulator-Superior-APK`.
5. Ekstrak artifact dan install `app-debug.apk`.

## Pasang di deretan Wi-Fi / Data Seluler
1. Tarik panel notifikasi dari atas layar dua kali.
2. Tekan ikon pensil / Edit.
3. Cari tile **Kalkulator**, lalu tarik ke deretan tombol aktif.
4. Tekan **Selesai**. Sekarang kalkulator bisa dibuka langsung dari Quick Settings.

Catatan: Android/Realme tidak mengizinkan aplikasi biasa menambahkan tile secara otomatis. Tile perlu ditambahkan sekali secara manual melalui menu Edit Quick Settings. Aplikasi juga tersedia seperti aplikasi biasa di launcher.
